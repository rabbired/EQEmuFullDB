/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_timers` (
  `charid` int(12) unsigned NOT NULL DEFAULT '0',
  `ability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `begin` int(10) unsigned NOT NULL DEFAULT '0',
  `end` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`ability`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `sharedplat` int(11) unsigned NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '',
  `status` int(5) NOT NULL DEFAULT '0',
  `lsaccount_id` int(11) unsigned DEFAULT NULL,
  `gmspeed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `revoked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `karma` int(5) unsigned NOT NULL DEFAULT '0',
  `minilogin_ip` varchar(32) NOT NULL DEFAULT '',
  `hideme` tinyint(4) NOT NULL DEFAULT '0',
  `rulesflag` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `suspendeduntil` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_creation` int(10) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(4) NOT NULL DEFAULT '0',
  `ban_reason` text,
  `suspend_reason` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `lsaccount_id` (`lsaccount_id`)
) ENGINE=MyISAM AUTO_INCREMENT=85788 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_flags` (
  `p_accid` int(10) unsigned NOT NULL,
  `p_flag` varchar(50) NOT NULL,
  `p_value` varchar(80) NOT NULL,
  PRIMARY KEY (`p_accid`,`p_flag`),
  KEY `p_accid` (`p_accid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_ip` (
  `accid` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '1',
  `lastused` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `ip` (`accid`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_rewards` (
  `account_id` int(10) unsigned NOT NULL,
  `reward_id` int(10) unsigned NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  UNIQUE KEY `account_reward` (`account_id`,`reward_id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adventure_id` smallint(5) unsigned NOT NULL,
  `instance_id` int(11) NOT NULL DEFAULT '-1',
  `count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `assassinate_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time_created` int(10) unsigned NOT NULL DEFAULT '0',
  `time_zoned` int(10) unsigned NOT NULL DEFAULT '0',
  `time_completed` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1798 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_members` (
  `id` int(10) unsigned NOT NULL,
  `charid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`charid`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_stats` (
  `player_id` int(10) unsigned NOT NULL,
  `guk_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mir_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mmc_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ruj_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tak_wins` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guk_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mir_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mmc_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ruj_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tak_losses` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  UNIQUE KEY `player_id` (`player_id`),
  KEY `player_id_2` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Banned_IPs` (
  `ip_address` varchar(20) NOT NULL DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bugs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `zone` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ui` varchar(128) NOT NULL,
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `type` varchar(64) NOT NULL,
  `flag` tinyint(3) unsigned NOT NULL,
  `target` varchar(64) DEFAULT NULL,
  `bug` varchar(1024) NOT NULL,
  `date` date NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=711 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buyer` (
  `charid` int(11) NOT NULL DEFAULT '0',
  `buyslot` int(11) NOT NULL DEFAULT '0',
  `itemid` int(11) NOT NULL DEFAULT '0',
  `itemname` varchar(65) NOT NULL DEFAULT '',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`buyslot`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `char_recipe_list` (
  `char_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `madecount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `last_name` varchar(64) NOT NULL DEFAULT '',
  `title` varchar(32) NOT NULL DEFAULT '',
  `suffix` varchar(32) NOT NULL DEFAULT '',
  `zone_id` int(11) unsigned NOT NULL DEFAULT '0',
  `zone_instance` int(11) unsigned NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `heading` float NOT NULL DEFAULT '0',
  `gender` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `race` smallint(11) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `deity` int(11) unsigned NOT NULL DEFAULT '0',
  `birthday` int(11) unsigned NOT NULL DEFAULT '0',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `time_played` int(11) unsigned NOT NULL DEFAULT '0',
  `level2` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `anon` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `gm` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `face` int(11) unsigned NOT NULL DEFAULT '0',
  `hair_color` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `hair_style` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `beard` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `beard_color` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `eye_color_1` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `eye_color_2` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `drakkin_heritage` int(11) unsigned NOT NULL DEFAULT '0',
  `drakkin_tattoo` int(11) unsigned NOT NULL DEFAULT '0',
  `drakkin_details` int(11) unsigned NOT NULL DEFAULT '0',
  `ability_time_seconds` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `ability_number` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `ability_time_minutes` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `ability_time_hours` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `exp` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_points_spent` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_exp` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_points` int(11) unsigned NOT NULL DEFAULT '0',
  `group_leadership_exp` int(11) unsigned NOT NULL DEFAULT '0',
  `raid_leadership_exp` int(11) unsigned NOT NULL DEFAULT '0',
  `group_leadership_points` int(11) unsigned NOT NULL DEFAULT '0',
  `raid_leadership_points` int(11) unsigned NOT NULL DEFAULT '0',
  `points` int(11) unsigned NOT NULL DEFAULT '0',
  `cur_hp` int(11) unsigned NOT NULL DEFAULT '0',
  `mana` int(11) unsigned NOT NULL DEFAULT '0',
  `endurance` int(11) unsigned NOT NULL DEFAULT '0',
  `intoxication` int(11) unsigned NOT NULL DEFAULT '0',
  `str` int(11) unsigned NOT NULL DEFAULT '0',
  `sta` int(11) unsigned NOT NULL DEFAULT '0',
  `cha` int(11) unsigned NOT NULL DEFAULT '0',
  `dex` int(11) unsigned NOT NULL DEFAULT '0',
  `int` int(11) unsigned NOT NULL DEFAULT '0',
  `agi` int(11) unsigned NOT NULL DEFAULT '0',
  `wis` int(11) unsigned NOT NULL DEFAULT '0',
  `zone_change_count` int(11) unsigned NOT NULL DEFAULT '0',
  `toxicity` int(11) unsigned NOT NULL DEFAULT '0',
  `hunger_level` int(11) unsigned NOT NULL DEFAULT '0',
  `thirst_level` int(11) unsigned NOT NULL DEFAULT '0',
  `ability_up` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_guk` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_mir` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_mmc` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_ruj` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_tak` int(11) unsigned NOT NULL DEFAULT '0',
  `ldon_points_available` int(11) unsigned NOT NULL DEFAULT '0',
  `tribute_time_remaining` int(11) unsigned NOT NULL DEFAULT '0',
  `career_tribute_points` int(11) unsigned NOT NULL DEFAULT '0',
  `tribute_points` int(11) unsigned NOT NULL DEFAULT '0',
  `tribute_active` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_status` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `pvp_kills` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_deaths` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_current_points` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_career_points` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_best_kill_streak` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_worst_death_streak` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_current_kill_streak` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp2` int(11) unsigned NOT NULL DEFAULT '0',
  `pvp_type` int(11) unsigned NOT NULL DEFAULT '0',
  `show_helm` int(11) unsigned NOT NULL DEFAULT '0',
  `group_auto_consent` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `raid_auto_consent` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `guild_auto_consent` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `leadership_exp_on` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `RestTimer` int(11) unsigned NOT NULL DEFAULT '0',
  `air_remaining` int(11) unsigned NOT NULL DEFAULT '0',
  `autosplit_enabled` int(11) unsigned NOT NULL DEFAULT '0',
  `lfp` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lfg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mailkey` char(16) NOT NULL DEFAULT '',
  `xtargets` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `firstlogon` tinyint(3) NOT NULL DEFAULT '0',
  `e_aa_effects` int(11) unsigned NOT NULL DEFAULT '0',
  `e_percent_to_aa` int(11) unsigned NOT NULL DEFAULT '0',
  `e_expended_aa_spent` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_points_spent_old` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_points_old` int(11) unsigned NOT NULL DEFAULT '0',
  `e_last_invsnapshot` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=678341 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_currency` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `platinum` int(11) unsigned NOT NULL DEFAULT '0',
  `gold` int(11) unsigned NOT NULL DEFAULT '0',
  `silver` int(11) unsigned NOT NULL DEFAULT '0',
  `copper` int(11) unsigned NOT NULL DEFAULT '0',
  `platinum_bank` int(11) unsigned NOT NULL DEFAULT '0',
  `gold_bank` int(11) unsigned NOT NULL DEFAULT '0',
  `silver_bank` int(11) unsigned NOT NULL DEFAULT '0',
  `copper_bank` int(11) unsigned NOT NULL DEFAULT '0',
  `platinum_cursor` int(11) unsigned NOT NULL DEFAULT '0',
  `gold_cursor` int(11) unsigned NOT NULL DEFAULT '0',
  `silver_cursor` int(11) unsigned NOT NULL DEFAULT '0',
  `copper_cursor` int(11) unsigned NOT NULL DEFAULT '0',
  `radiant_crystals` int(11) unsigned NOT NULL DEFAULT '0',
  `career_radiant_crystals` int(11) unsigned NOT NULL DEFAULT '0',
  `ebon_crystals` int(11) unsigned NOT NULL DEFAULT '0',
  `career_ebon_crystals` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_alternate_abilities` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `aa_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `aa_value` smallint(11) unsigned NOT NULL DEFAULT '0',
  `charges` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`aa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_bind` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slot` int(4) NOT NULL DEFAULT '0',
  `zone_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `instance_id` mediumint(11) unsigned NOT NULL DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `heading` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678341 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_corpses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `zone_id` smallint(5) NOT NULL DEFAULT '0',
  `instance_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  `heading` float NOT NULL DEFAULT '0',
  `time_of_death` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_rezzed` tinyint(3) unsigned DEFAULT '0',
  `is_buried` tinyint(3) NOT NULL DEFAULT '0',
  `was_at_graveyard` tinyint(3) NOT NULL DEFAULT '0',
  `is_locked` tinyint(11) DEFAULT '0',
  `exp` int(11) unsigned DEFAULT '0',
  `size` int(11) unsigned DEFAULT '0',
  `level` int(11) unsigned DEFAULT '0',
  `race` int(11) unsigned DEFAULT '0',
  `gender` int(11) unsigned DEFAULT '0',
  `class` int(11) unsigned DEFAULT '0',
  `deity` int(11) unsigned DEFAULT '0',
  `texture` int(11) unsigned DEFAULT '0',
  `helm_texture` int(11) unsigned DEFAULT '0',
  `copper` int(11) unsigned DEFAULT '0',
  `silver` int(11) unsigned DEFAULT '0',
  `gold` int(11) unsigned DEFAULT '0',
  `platinum` int(11) unsigned DEFAULT '0',
  `hair_color` int(11) unsigned DEFAULT '0',
  `beard_color` int(11) unsigned DEFAULT '0',
  `eye_color_1` int(11) unsigned DEFAULT '0',
  `eye_color_2` int(11) unsigned DEFAULT '0',
  `hair_style` int(11) unsigned DEFAULT '0',
  `face` int(11) unsigned DEFAULT '0',
  `beard` int(11) unsigned DEFAULT '0',
  `drakkin_heritage` int(11) unsigned DEFAULT '0',
  `drakkin_tattoo` int(11) unsigned DEFAULT '0',
  `drakkin_details` int(11) unsigned DEFAULT '0',
  `wc_1` int(11) unsigned DEFAULT '0',
  `wc_2` int(11) unsigned DEFAULT '0',
  `wc_3` int(11) unsigned DEFAULT '0',
  `wc_4` int(11) unsigned DEFAULT '0',
  `wc_5` int(11) unsigned DEFAULT '0',
  `wc_6` int(11) unsigned DEFAULT '0',
  `wc_7` int(11) unsigned DEFAULT '0',
  `wc_8` int(11) unsigned DEFAULT '0',
  `wc_9` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `zoneid` (`zone_id`),
  KEY `instanceid` (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1900816 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_corpse_items` (
  `corpse_id` int(11) unsigned NOT NULL,
  `equip_slot` int(11) unsigned NOT NULL,
  `item_id` int(11) unsigned DEFAULT NULL,
  `charges` int(11) unsigned DEFAULT NULL,
  `aug_1` int(11) unsigned DEFAULT '0',
  `aug_2` int(11) unsigned DEFAULT '0',
  `aug_3` int(11) unsigned DEFAULT '0',
  `aug_4` int(11) unsigned DEFAULT '0',
  `aug_5` int(11) unsigned DEFAULT '0',
  `aug_6` int(11) NOT NULL DEFAULT '0',
  `attuned` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`corpse_id`,`equip_slot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_languages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `value` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`lang_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678341 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_skills` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skill_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `value` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`skill_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678341 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spells` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slot_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `spell_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678341 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_memmed_spells` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `slot_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `spell_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_disciplines` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `slot_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  `disc_id` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_material` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slot` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `blue` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `green` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `red` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `use_tint` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `color` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=678213 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_tribute` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `tier` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `tribute` int(11) unsigned NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_bandolier` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `bandolier_id` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `bandolier_slot` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `icon` int(11) unsigned NOT NULL DEFAULT '0',
  `bandolier_name` varchar(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`bandolier_id`,`bandolier_slot`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_potionbelt` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `potion_id` tinyint(11) unsigned NOT NULL DEFAULT '0',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `icon` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`potion_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_inspect_messages` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `inspect_message` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_leadership_abilities` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `slot` smallint(11) unsigned NOT NULL DEFAULT '0',
  `rank` smallint(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`slot`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_activities` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `activityid` int(11) unsigned NOT NULL DEFAULT '0',
  `donecount` int(11) unsigned NOT NULL DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`charid`,`taskid`,`activityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_alt_currency` (
  `char_id` int(10) unsigned NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  PRIMARY KEY (`char_id`,`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_buffs` (
  `character_id` int(10) unsigned NOT NULL,
  `slot_id` tinyint(3) unsigned NOT NULL,
  `spell_id` smallint(10) unsigned NOT NULL,
  `caster_level` tinyint(3) unsigned NOT NULL,
  `caster_name` varchar(64) NOT NULL,
  `ticsremaining` int(11) NOT NULL,
  `counters` int(10) unsigned NOT NULL,
  `numhits` int(10) unsigned NOT NULL,
  `melee_rune` int(10) unsigned NOT NULL,
  `magic_rune` int(10) unsigned NOT NULL,
  `persistent` tinyint(3) unsigned NOT NULL,
  `dot_rune` int(10) NOT NULL DEFAULT '0',
  `caston_x` int(10) NOT NULL DEFAULT '0',
  `caston_y` int(10) NOT NULL DEFAULT '0',
  `caston_z` int(10) NOT NULL DEFAULT '0',
  `ExtraDIChance` int(10) NOT NULL DEFAULT '0',
  `instrument_mod` int(10) NOT NULL DEFAULT '10',
  PRIMARY KEY (`character_id`,`slot_id`),
  KEY `character_id` (`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_enabledtasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`taskid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_buffs` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `spell_id` int(11) NOT NULL,
  `caster_level` tinyint(4) NOT NULL DEFAULT '0',
  `castername` varchar(64) NOT NULL DEFAULT '',
  `ticsremaining` int(11) NOT NULL DEFAULT '0',
  `counters` int(11) NOT NULL DEFAULT '0',
  `numhits` int(11) NOT NULL DEFAULT '0',
  `rune` int(11) NOT NULL DEFAULT '0',
  `instrument_mod` tinyint(3) unsigned NOT NULL DEFAULT '10',
  PRIMARY KEY (`char_id`,`pet`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_info` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `petname` varchar(64) NOT NULL DEFAULT '',
  `petpower` int(11) NOT NULL DEFAULT '0',
  `spell_id` int(11) NOT NULL DEFAULT '0',
  `hp` int(11) NOT NULL DEFAULT '0',
  `mana` int(11) NOT NULL DEFAULT '0',
  `size` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`pet`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_inventory` (
  `char_id` int(11) NOT NULL,
  `pet` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`char_id`,`pet`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_tasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `slot` int(11) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `acceptedtime` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`charid`,`taskid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatchannels` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `owner` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `minstatus` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `completed_tasks` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `completedtime` int(11) unsigned NOT NULL DEFAULT '0',
  `taskid` int(11) unsigned NOT NULL DEFAULT '0',
  `activityid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`completedtime`,`taskid`,`activityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discovered_items` (
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `char_name` varchar(64) NOT NULL DEFAULT '',
  `discovered_date` int(11) unsigned NOT NULL DEFAULT '0',
  `account_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountname` varchar(30) NOT NULL DEFAULT '',
  `accountid` int(10) unsigned DEFAULT '0',
  `status` int(5) NOT NULL DEFAULT '0',
  `charname` varchar(64) NOT NULL DEFAULT '',
  `target` varchar(64) DEFAULT 'None',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `descriptiontype` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `event_nid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=78999 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faction_values` (
  `char_id` int(4) NOT NULL DEFAULT '0',
  `faction_id` int(4) NOT NULL DEFAULT '0',
  `current_value` smallint(6) NOT NULL DEFAULT '0',
  `temp` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`faction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `charid` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 = Friend, 0 = Ignore',
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`charid`,`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_ips` (
  `name` varchar(64) NOT NULL,
  `account_id` int(11) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  UNIQUE KEY `account_id` (`account_id`,`ip_address`),
  UNIQUE KEY `account_id_2` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_id` (
  `groupid` int(4) NOT NULL,
  `charid` int(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ismerc` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`,`charid`,`ismerc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_leaders` (
  `gid` int(4) NOT NULL DEFAULT '0',
  `leadername` varchar(64) NOT NULL DEFAULT '',
  `marknpc` varchar(64) NOT NULL DEFAULT '',
  `leadershipaa` tinyblob,
  `maintank` varchar(64) NOT NULL DEFAULT '',
  `assist` varchar(64) NOT NULL DEFAULT '',
  `puller` varchar(64) NOT NULL DEFAULT '',
  `mentoree` varchar(64) NOT NULL,
  `mentor_percent` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guilds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `leader` int(11) NOT NULL DEFAULT '0',
  `minstatus` smallint(5) NOT NULL DEFAULT '0',
  `motd` text NOT NULL,
  `tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `motd_setter` varchar(64) NOT NULL DEFAULT '',
  `channel` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(512) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `leader` (`leader`)
) ENGINE=MyISAM AUTO_INCREMENT=774 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(4) unsigned NOT NULL DEFAULT '0',
  `itemid` int(10) unsigned NOT NULL DEFAULT '0',
  `qty` int(10) unsigned NOT NULL DEFAULT '0',
  `donator` varchar(64) DEFAULT NULL,
  `permissions` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `whofor` varchar(64) DEFAULT NULL,
  KEY `guildid` (`guildid`),
  KEY `area` (`area`),
  KEY `slot` (`slot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_ranks` (
  `guild_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `can_hear` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_speak` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_invite` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_remove` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_promote` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_demote` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_motd` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `can_warpeace` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild_id`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_relations` (
  `guild1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guild2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `relation` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild1`,`guild2`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_members` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `guild_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tribute_enable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `total_tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `last_tribute` int(10) unsigned NOT NULL DEFAULT '0',
  `banker` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `public_note` text NOT NULL,
  `alt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hackers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `account` text NOT NULL,
  `name` text NOT NULL,
  `hacked` text NOT NULL,
  `zone` text,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1845603 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_list_player` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `charid` int(11) unsigned NOT NULL DEFAULT '0',
  `slotid` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `itemid` int(11) unsigned DEFAULT '0',
  `charges` smallint(3) unsigned DEFAULT '0',
  `color` int(11) unsigned NOT NULL DEFAULT '0',
  `augslot1` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot2` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot3` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot4` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot5` mediumint(7) unsigned DEFAULT '0',
  `augslot6` mediumint(7) NOT NULL DEFAULT '0',
  `instnodrop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `custom_data` text,
  `ornamenticon` int(11) unsigned NOT NULL DEFAULT '0',
  `ornamentidfile` int(11) unsigned NOT NULL DEFAULT '0',
  `ornament_hero_model` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`,`slotid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_tick` (
  `it_itemid` int(11) NOT NULL,
  `it_chance` int(11) NOT NULL,
  `it_level` int(11) NOT NULL,
  `it_id` int(11) NOT NULL AUTO_INCREMENT,
  `it_qglobal` varchar(50) NOT NULL,
  `it_bagslot` tinyint(4) NOT NULL,
  PRIMARY KEY (`it_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyring` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `launcher_zones` (
  `launcher` varchar(64) NOT NULL DEFAULT '',
  `zone` varchar(32) NOT NULL DEFAULT '',
  `port` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`launcher`,`zone`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lfguild` (
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL,
  `comment` varchar(256) NOT NULL,
  `fromlevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tolevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `classes` int(10) unsigned NOT NULL DEFAULT '0',
  `aacount` int(10) unsigned NOT NULL DEFAULT '0',
  `timezone` int(10) unsigned NOT NULL DEFAULT '0',
  `timeposted` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charid` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `from` varchar(100) NOT NULL DEFAULT '',
  `subject` varchar(200) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `to` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msgid`),
  KEY `charid` (`charid`)
) ENGINE=MyISAM AUTO_INCREMENT=2559 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchantlist_temp` (
  `npcid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `itemid` int(10) unsigned NOT NULL DEFAULT '0',
  `charges` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`npcid`,`slot`),
  KEY `npcid_2` (`npcid`,`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `name_filter` (
  `name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_contents` (
  `zoneid` int(11) unsigned NOT NULL DEFAULT '0',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `bagidx` int(11) unsigned NOT NULL DEFAULT '0',
  `itemid` int(11) unsigned NOT NULL DEFAULT '0',
  `charges` smallint(3) NOT NULL DEFAULT '0',
  `droptime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `augslot1` mediumint(7) unsigned DEFAULT '0',
  `augslot2` mediumint(7) unsigned DEFAULT '0',
  `augslot3` mediumint(7) unsigned DEFAULT '0',
  `augslot4` mediumint(7) unsigned DEFAULT '0',
  `augslot5` mediumint(7) unsigned DEFAULT '0',
  `augslot6` mediumint(7) NOT NULL DEFAULT '0',
  PRIMARY KEY (`parentid`,`bagidx`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petitions` (
  `dib` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `petid` int(10) unsigned NOT NULL DEFAULT '0',
  `charname` varchar(32) NOT NULL DEFAULT '',
  `accountname` varchar(32) NOT NULL DEFAULT '',
  `lastgm` varchar(32) NOT NULL DEFAULT '',
  `petitiontext` text NOT NULL,
  `gmtext` text,
  `zone` varchar(32) NOT NULL DEFAULT '',
  `urgency` int(11) NOT NULL DEFAULT '0',
  `charclass` int(11) NOT NULL DEFAULT '0',
  `charrace` int(11) NOT NULL DEFAULT '0',
  `charlevel` int(11) NOT NULL DEFAULT '0',
  `checkouts` int(11) NOT NULL DEFAULT '0',
  `unavailables` int(11) NOT NULL DEFAULT '0',
  `ischeckedout` tinyint(4) NOT NULL DEFAULT '0',
  `senttime` bigint(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dib`),
  KEY `petid` (`petid`)
) ENGINE=MyISAM AUTO_INCREMENT=2274 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_titlesets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(11) unsigned NOT NULL,
  `title_set` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1309 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_move_record` (
  `move_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `stack_size` mediumint(7) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  `postaction` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`move_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_move_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_npc_kill_record` (
  `fight_id` int(11) NOT NULL AUTO_INCREMENT,
  `npc_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fight_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_npc_kill_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_speech` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(64) NOT NULL,
  `to` varchar(64) NOT NULL,
  `message` varchar(256) NOT NULL,
  `minstatus` smallint(5) NOT NULL,
  `guilddbid` int(11) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `timerecorded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2011279 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_trade_record` (
  `trade_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char1_id` int(11) DEFAULT '0',
  `char1_pp` int(11) DEFAULT '0',
  `char1_gp` int(11) DEFAULT '0',
  `char1_sp` int(11) DEFAULT '0',
  `char1_cp` int(11) DEFAULT '0',
  `char1_items` mediumint(7) DEFAULT '0',
  `char2_id` int(11) DEFAULT '0',
  `char2_pp` int(11) DEFAULT '0',
  `char2_gp` int(11) DEFAULT '0',
  `char2_sp` int(11) DEFAULT '0',
  `char2_cp` int(11) DEFAULT '0',
  `char2_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`trade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_trade_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `from_id` int(11) DEFAULT '0',
  `from_slot` mediumint(7) DEFAULT '0',
  `to_id` int(11) DEFAULT '0',
  `to_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_merchant_transaction_record` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `zone_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `merchant_pp` int(11) DEFAULT '0',
  `merchant_gp` int(11) DEFAULT '0',
  `merchant_sp` int(11) DEFAULT '0',
  `merchant_cp` int(11) DEFAULT '0',
  `merchant_items` mediumint(7) DEFAULT '0',
  `char_id` int(11) DEFAULT '0',
  `char_pp` int(11) DEFAULT '0',
  `char_gp` int(11) DEFAULT '0',
  `char_sp` int(11) DEFAULT '0',
  `char_cp` int(11) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_merchant_transaction_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_delete_record` (
  `delete_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `char_id` int(11) DEFAULT '0',
  `stack_size` mediumint(7) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`delete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_delete_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_handin_record` (
  `handin_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `quest_id` int(11) DEFAULT '0',
  `char_id` int(11) DEFAULT '0',
  `char_pp` int(11) DEFAULT '0',
  `char_gp` int(11) DEFAULT '0',
  `char_sp` int(11) DEFAULT '0',
  `char_cp` int(11) DEFAULT '0',
  `char_items` mediumint(7) DEFAULT '0',
  `npc_id` int(11) DEFAULT '0',
  `npc_pp` int(11) DEFAULT '0',
  `npc_gp` int(11) DEFAULT '0',
  `npc_sp` int(11) DEFAULT '0',
  `npc_cp` int(11) DEFAULT '0',
  `npc_items` mediumint(7) DEFAULT '0',
  PRIMARY KEY (`handin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_handin_record_entries` (
  `event_id` int(11) DEFAULT '0',
  `action_type` char(6) DEFAULT 'action',
  `char_slot` mediumint(7) DEFAULT '0',
  `item_id` int(11) DEFAULT '0',
  `charges` mediumint(7) DEFAULT '0',
  `aug_1` int(11) DEFAULT '0',
  `aug_2` int(11) DEFAULT '0',
  `aug_3` int(11) DEFAULT '0',
  `aug_4` int(11) DEFAULT '0',
  `aug_5` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_aa_rate_hourly` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `hour_time` int(11) NOT NULL,
  `aa_count` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`char_id`,`hour_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qs_player_events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(11) DEFAULT '0',
  `event` int(11) unsigned DEFAULT '0',
  `event_desc` varchar(255) DEFAULT NULL,
  `time` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_globals` (
  `charid` int(11) NOT NULL DEFAULT '0',
  `npcid` int(11) NOT NULL DEFAULT '0',
  `zoneid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(65) NOT NULL DEFAULT '',
  `value` varchar(128) NOT NULL DEFAULT '?',
  `expdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`charid`,`npcid`,`zoneid`,`name`),
  UNIQUE KEY `qname` (`name`,`charid`,`npcid`,`zoneid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raid_details` (
  `raidid` int(4) NOT NULL DEFAULT '0',
  `loottype` int(4) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `motd` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`raidid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raid_leaders` (
  `gid` int(4) unsigned NOT NULL,
  `rid` int(4) unsigned NOT NULL,
  `marknpc` varchar(64) NOT NULL,
  `maintank` varchar(64) NOT NULL,
  `assist` varchar(64) NOT NULL,
  `puller` varchar(64) NOT NULL,
  `leadershipaa` tinyblob NOT NULL,
  `mentoree` varchar(64) NOT NULL,
  `mentor_percent` int(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raid_members` (
  `raidid` int(4) NOT NULL DEFAULT '0',
  `charid` int(4) NOT NULL DEFAULT '0',
  `groupid` int(4) unsigned NOT NULL DEFAULT '0',
  `_class` tinyint(4) NOT NULL DEFAULT '0',
  `level` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `isgroupleader` tinyint(1) NOT NULL DEFAULT '0',
  `israidleader` tinyint(1) NOT NULL DEFAULT '0',
  `islooter` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `reported` varchar(64) DEFAULT NULL,
  `reported_text` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respawn_times` (
  `id` int(11) NOT NULL DEFAULT '0',
  `start` int(11) NOT NULL DEFAULT '0',
  `duration` int(11) NOT NULL DEFAULT '0',
  `instance_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sharedbank` (
  `acctid` int(11) unsigned DEFAULT '0',
  `slotid` mediumint(7) unsigned DEFAULT '0',
  `itemid` int(11) unsigned DEFAULT '0',
  `charges` smallint(3) unsigned DEFAULT '0',
  `augslot1` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot2` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot3` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot4` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot5` mediumint(7) unsigned NOT NULL DEFAULT '0',
  `augslot6` mediumint(7) NOT NULL DEFAULT '0',
  `custom_data` text,
  UNIQUE KEY `account` (`acctid`,`slotid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spell_globals` (
  `spellid` int(11) NOT NULL,
  `spell_name` varchar(64) NOT NULL DEFAULT '',
  `qglobal` varchar(65) NOT NULL DEFAULT '',
  `value` varchar(65) NOT NULL DEFAULT '',
  PRIMARY KEY (`spellid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timers` (
  `char_id` int(11) NOT NULL DEFAULT '0',
  `type` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `start` int(10) unsigned NOT NULL DEFAULT '0',
  `duration` int(10) unsigned NOT NULL DEFAULT '0',
  `enable` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trader` (
  `char_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `serialnumber` int(10) unsigned NOT NULL DEFAULT '0',
  `charges` int(11) NOT NULL DEFAULT '0',
  `item_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `slot_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`char_id`,`slot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trader_audit` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `seller` varchar(64) NOT NULL DEFAULT '',
  `buyer` varchar(64) NOT NULL DEFAULT '',
  `itemname` varchar(64) NOT NULL DEFAULT '',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `totalcost` int(11) NOT NULL DEFAULT '0',
  `trantype` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zone_flags` (
  `charID` int(11) NOT NULL DEFAULT '0',
  `zoneID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charID`,`zoneID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `command_settings` (
  `command` varchar(128) NOT NULL DEFAULT '',
  `access` int(11) NOT NULL DEFAULT '0',
  `aliases` varchar(256) NOT NULL DEFAULT '',
  PRIMARY KEY (`command`),
  UNIQUE KEY `UK_command_settings_1` (`command`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `command_settings` VALUES ('acceptrules',90,''),('advnpcspawn',150,'advnpc'),('aggro',80,''),('aggrozone',200,''),('ai',100,''),('appearance',150,''),('apply_shared_memory',250,''),('attack',150,''),('augmentitem',250,'aug'),('ban',200,''),('beard',80,''),('beardcolor',80,''),('bestz',80,''),('bind',80,''),('camerashake',80,''),('castspell',90,'cast'),('chat',200,''),('checklos',50,'los'),('clearinvsnapshots',200,''),('connectworldserver',200,'connectworld'),('corpse',90,''),('crashtest',201,''),('cvs',80,''),('damage',150,''),('date',150,''),('dbspawn2',100,''),('delacct',200,''),('deletegraveyard',200,''),('delpetition',80,''),('depop',100,''),('depopzone',100,''),('details',80,''),('disablerecipe',80,''),('disarmtrap',80,''),('distance',80,''),('doanim',50,''),('emote',150,''),('emotesearch',80,''),('emoteview',80,''),('enablerecipe',80,''),('equipitem',50,''),('face',80,''),('findaliases',0,'fa'),('findnpctype',90,'fn'),('findspell',90,'fs|spfind'),('findzone',1,'fz'),('fixmob',150,''),('flag',201,''),('flagedit',150,''),('flags',80,''),('flymode',80,''),('fov',80,''),('freeze',100,''),('gassign',150,''),('gender',90,''),('getplayerburiedcorpsecount',100,''),('getvariable',200,''),('ginfo',20,''),('giveitem',150,'gi'),('givemoney',150,''),('globalview',80,''),('gm',80,''),('gmspeed',80,''),('goto',80,''),('grid',150,''),('guild',80,'guilds'),('guildapprove',0,''),('guildcreate',0,''),('guildlist',0,''),('hair',80,''),('haircolor',80,''),('haste',100,''),('hatelist',80,''),('heal',100,''),('helm',80,''),('help',0,''),('heritage',80,''),('heromodel',200,'hm'),('hideme',80,'gmhideme'),('hotfix',250,''),('hp',90,''),('incstat',200,''),('instance',80,''),('interrogateinv',0,''),('interrupt',50,''),('invsnapshot',80,''),('invul',80,'invulnerable'),('ipban',201,''),('iplookup',200,''),('iteminfo',10,''),('itemsearch',90,'fi|finditem|search'),('kick',80,''),('kill',80,''),('lastname',80,''),('level',150,''),('listnpcs',90,''),('listpetition',80,''),('load_shared_memory',250,''),('loc',0,''),('lock',200,''),('logs',250,''),('logtest',250,''),('makepet',150,''),('mana',100,''),('maxskills',90,''),('memspell',100,''),('merchant_close_shop',100,'close_shop'),('merchant_open_shop',100,'open_shop'),('modifynpcstat',150,''),('motd',200,''),('movechar',80,''),('myskills',0,''),('mysql',255,''),('mysqltest',250,''),('mystats',50,''),('name',100,''),('netstats',200,''),('npccast',90,''),('npcedit',150,''),('npcemote',80,''),('npcloot',150,''),('npcsay',80,''),('npcshout',90,''),('npcspawn',100,''),('npcspecialattk',150,'npcspecialatk|npcspecialattack'),('npcstats',90,''),('npctypespawn',90,'dbspawn'),('npctype_cache',250,''),('nukebuffs',100,''),('nukeitem',150,''),('object',100,''),('oocmute',200,''),('opcode',150,''),('path',150,''),('peekinv',80,''),('peqzone',2,''),('permaclass',150,''),('permagender',150,''),('permarace',150,''),('petitioninfo',20,''),('pf',0,''),('picklock',0,''),('pvp',80,''),('qglobal',150,''),('questerrors',0,''),('race',90,''),('raidloot',0,''),('randomfeatures',90,''),('refreshgroup',0,''),('reloadaa',200,''),('reloadallrules',80,''),('reloademote',80,''),('reloadlevelmods',80,''),('reloadperlexportsettings',255,''),('reloadqst',80,'reloadquest|rq'),('reloadrulesworld',80,''),('reloadstatic',150,''),('reloadtitles',150,''),('reloadworld',255,''),('reloadzps',150,'reloadzonepoints'),('repop',90,''),('repopclose',100,''),('resetaa',100,''),('resetaa_timer',200,''),('revoke',80,''),('rules',200,''),('save',80,''),('scribespell',90,''),('scribespells',100,''),('sendzonespawns',200,''),('sensetrap',0,''),('serverinfo',201,''),('serverrules',90,''),('setaapts',100,'setaapoints'),('setaaxp',100,'setaaexp'),('setadventurepoints',200,''),('setanim',200,''),('setcrystals',100,''),('setfaction',170,''),('setgraveyard',200,''),('setlanguage',50,''),('setlsinfo',0,''),('setpass',150,''),('setpvppoints',100,''),('setskill',90,''),('setskillall',100,'setallskill|setallskills'),('setstartzone',80,''),('setstat',255,''),('setxp',100,'setexp'),('showbonusstats',50,''),('showbuffs',80,''),('shownumhits',0,''),('showskills',50,''),('showspellslist',100,''),('showstats',80,''),('shutdown',200,''),('size',90,''),('spawn',150,''),('spawnfix',80,''),('spawnstatus',150,''),('spellinfo',10,''),('spoff',0,''),('spon',0,''),('stun',100,''),('summon',80,''),('summonburiedplayercorpse',100,''),('summonitem',150,'si'),('suspend',100,''),('task',150,''),('tattoo',80,''),('tempname',100,''),('texture',150,''),('time',90,''),('timers',200,''),('timezone',90,''),('title',100,''),('titlesuffix',50,''),('traindisc',100,''),('tune',100,''),('undyeme',0,''),('unfreeze',100,''),('unlock',150,''),('unscribespell',90,''),('unscribespells',100,''),('untraindisc',180,''),('untraindiscs',180,''),('uptime',10,''),('version',0,''),('viewnpctype',100,''),('viewpetition',80,''),('wc',200,''),('weather',90,''),('worldshutdown',200,''),('wp',150,''),('wpadd',150,''),('wpinfo',150,''),('xtargets',150,''),('zclip',150,''),('zcolor',150,''),('zheader',150,''),('zone',80,''),('zonebootup',100,''),('zoneinstance',80,''),('zonelock',200,''),('zoneshutdown',200,''),('zonespawn',250,''),('zonestatus',150,''),('zopp',250,''),('zsafecoords',150,''),('zsave',200,''),('zsky',150,''),('zstats',80,''),('zunderworld',80,''),('zuwcoords',80,'');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `launcher` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `dynamics` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `launcher` VALUES ('peq',40),('zone',5);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_sets` (
  `ruleset_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ruleset_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `rule_sets` VALUES (3,'merc_test'),(1,'default'),(2,'pop+'),(10,'EQEmu_Default'),(4,'GoD'),(5,'raidzone'),(6,'OOW'),(20,'fix_pathing_z');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_values` (
  `ruleset_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rule_name` varchar(64) NOT NULL DEFAULT '',
  `rule_value` varchar(30) NOT NULL DEFAULT '',
  `notes` text,
  PRIMARY KEY (`ruleset_id`,`rule_name`),
  KEY `ruleset_id` (`ruleset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `rule_values` VALUES (2,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(2,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(20,'Map:FixPathingZWhenMoving','true',NULL),(1,'Skills:MaxTrainSpecializations','50',NULL),(1,'Skills:SwimmingStartValue','100',NULL),(1,'World:IsGMPetitionWindowEnabled','false',NULL),(1,'Spells:ReflectType','3',NULL),(1,'Spells:AI_EngagedNoSpellMaxRecast','1000',NULL),(1,'Spells:AI_EngagedBeneficialSelfChance','100',NULL),(1,'Character:UseNewStatsWindow','true',NULL),(1,'Character:ItemDSMitigationCap','50',NULL),(1,'Character:ItemSpellDmgCap','250',NULL),(1,'Character:TradeskillUpBlacksmithing','2',NULL),(1,'Character:ItemHealAmtCap','250',NULL),(1,'Character:TradeskillUpBrewing','3',NULL),(1,'Character:ItemClairvoyanceCap','250',NULL),(1,'Character:TradeskillUpBaking','2',NULL),(1,'Spells:EnableBlockedBuffs','true',NULL),(1,'Combat:NPCBashKickStunChance','15',NULL),(1,'Combat:MeleeCritDifficulty','8900',NULL),(1,'Character:ItemEnduranceRegenCap','15',NULL),(1,'Character:RespawnFromHoverTimer','300',NULL),(1,'Character:RespawnFromHover','false',NULL),(1,'Character:MarqueeHPUpdates','false',NULL),(1,'Combat:AdjustSpecialProcPerMinute','false',NULL),(1,'Combat:UseOldDamageIntervalRules','false',NULL),(1,'Spells:MaxTotalSlotsNPC','85',NULL),(1,'Spells:MaxSongSlotsNPC','10',NULL),(1,'Spells:MaxDiscSlotsNPC','1',NULL),(1,'Spells:MaxBuffSlotsNPC','85',NULL),(1,'Character:SoDClientUseSoDHPManaEnd','true',NULL),(1,'Character:UseOldClassExpPenalties','false',NULL),(1,'Skills:MaxTradeskillSearchSkillDiff','50',NULL),(1,'Skills:SenseHeadingStartValue','200',NULL),(1,'GM:MinStatusToSummonItem','250',NULL),(1,'Combat:HitCapPre10','20',NULL),(1,'Combat:MinHastedDelay','400',NULL),(1,'Combat:ArcheryBonusChance','50',NULL),(1,'Skills:UseLimitTradeskillSearchSkillDiff','true',NULL),(1,'Skills:TrainSenseHeading','false',NULL),(1,'Spells:NPC_UseFocusFromSpells','true',NULL),(1,'Character:DeathExpLossMaxLevel','255',NULL),(1,'Character:GreenModifier','40',NULL),(1,'World:GuildBankZoneID','345',NULL),(1,'Combat:DefaultRampageTargets','1',NULL),(1,'NPC:ReturnNonQuestNoDropItems','true',NULL),(1,'NPC:UseClassAsLastName','true',NULL),(1,'Spells:EnableSpellGlobals','false',NULL),(1,'Spells:UseCHAScribeHack','false',NULL),(1,'Spells:UseLiveSpellProjectileGFX','false',NULL),(1,'Zone:MarkMQWarpLT','false',NULL),(1,'Zone:HotZoneBonus','0.7500000000000',NULL),(1,'Chat:GlobalChatLevelLimit','1',NULL),(1,'Chat:KarmaGlobalChatLimit','72',NULL),(1,'Combat:FleeSnareHPRatio','21','HP at which snare will halt movement of a fleeing NPC.'),(1,'World:MaxClientsSetByStatus','false',NULL),(1,'Zone:EnableLoggedOffReplenishments','true',NULL),(1,'Zone:UseZoneController','false',NULL),(1,'AA:ExpPerPoint','23976503',NULL),(1,'Character:MaxFearDurationForPlayerCharacter','4',NULL),(1,'Character:MaxCharmDurationForPlayerCharacter','15',NULL),(1,'Character:BaseHPRegenBonusRaces','4352',NULL),(1,'AA:MaxEffectSlots','7','the highest slot # used in the aa_effects table. have to use MAX_AA_EFFECT_SLOTS for now'),(1,'Combat:RoundKickBonus','5',NULL),(1,'Combat:BackstabBonus','0',NULL),(1,'Combat:TigerClawBonus','10',NULL),(1,'Combat:ClothACSoftcap','75',NULL),(1,'Combat:EagleStrikeBonus','15',NULL),(1,'Combat:LeatherACSoftcap','100',NULL),(1,'Combat:DragonPunchBonus','20',NULL),(1,'Combat:MonkACSoftcap','120',NULL),(1,'Combat:FlyingKickBonus','25',NULL),(1,'Combat:ChainACSoftcap','200',NULL),(1,'Combat:MonkDamageTableBonus','10',NULL),(1,'Combat:PlateACSoftcap','300',NULL),(1,'Combat:MaxFlurryHits','2',NULL),(1,'Combat:MaxRampageTargets','3',NULL),(1,'Spells:SacrificeItemID','9963',NULL),(1,'Spells:MaxTotalSlotsPET','30',NULL),(1,'Spells:SacrificeMaxLevel','70',NULL),(1,'Spells:SacrificeMinLevel','46',NULL),(1,'Map:UseClosestZ','true',''),(1,'Map:FindBestZHeightAdjust','1',NULL),(1,'Pathing:ZDiffThreshold','80.0000000000000',NULL),(1,'Pathing:RouteUpdateFrequencyShort','1000',NULL),(1,'Pathing:RouteUpdateFrequencyNodeCount','5',NULL),(1,'Pathing:MinDistanceForLOSCheckShort','40000.0000000000000',NULL),(1,'Pathing:MinNodesTraversedForLOSCheck','3',NULL),(1,'Pathing:RouteUpdateFrequencyLong','5000',NULL),(1,'Pathing:LOSCheckFrequency','1000',NULL),(1,'Pathing:MaxNodesLeftForLOSCheck','4',''),(1,'Pathing:MinDistanceForLOSCheckLong','1000000.0000000000000',NULL),(1,'Pathing:Guard','true',NULL),(1,'Combat:ArcheryBaseDamageBonus','1.0000000000000',NULL),(1,'Pathing:Fear','true',NULL),(1,'Pathing:CullNodesFromStart','1',NULL),(1,'Pathing:CullNodesFromEnd','1',NULL),(1,'Pathing:CandidateNodeRangeZ','50.0000000000000',NULL),(1,'NPC:SmartLastFightingDelayMoving','true',NULL),(1,'NPC:NewLevelScaling','true',NULL),(1,'Aggro:AllowTickPulling','false',NULL),(1,'Combat:ArcheryBonusRequiresStationary','true',NULL),(1,'Combat:OldACSoftcapRules','false',NULL),(1,'NPC:LastFightingDelayMovingMax','30000',NULL),(1,'NPC:LastFightingDelayMovingMin','5000',NULL),(1,'NPC:NPCToNPCAggroTimerMax','6000',NULL),(1,'Zone:PEQZoneDebuff2','2209',NULL),(1,'Zone:ReservedInstances','30',NULL),(1,'Zone:PEQZoneDebuff1','4454',NULL),(1,'Zone:EbonCrystalItemID','40902',NULL),(1,'Zone:PEQZoneReuseTime','300',NULL),(1,'Zone:RadiantCrystalItemID','40903',NULL),(1,'Pathing:AggroReturnToGrid','true',NULL),(1,'Pathing:CandidateNodeRangeXY','400.0000000000000',NULL),(1,'Pathing:Aggro','true',NULL),(1,'Adventure:DistanceForRescueComplete','2500.0000000000000',NULL),(1,'Adventure:NumberKillsForBossSpawn','40',NULL),(1,'Adventure:DistanceForRescueAccept','10000.0000000000000',NULL),(1,'Adventure:MaxNumberForRaid','36',NULL),(1,'Adventure:MaxLevelRange','9',NULL),(1,'Adventure:MaxNumberForGroup','6',NULL),(1,'Adventure:MinNumberForRaid','18',NULL),(1,'Adventure:MinNumberForGroup','2',NULL),(1,'Adventure:ItemIDToEnablePorts','41000',NULL),(1,'Character:KillsPerGroupLeadershipAA','250',NULL),(1,'Character:KillsPerRaidLeadershipAA','250',NULL),(1,'Character:YellowModifier','110',NULL),(1,'Character:RedModifier','120',NULL),(1,'Character:WhiteModifier','105',NULL),(1,'Character:LightBlueModifier','85',NULL),(1,'Character:BlueModifier','100',NULL),(1,'Combat:NPCBonusHitChance','26.0000000000000',NULL),(1,'Character:UseXPConScaling','true',NULL),(1,'Zone:UsePEQZoneDebuffs','false',NULL),(1,'Character:RestRegenTimeToActivate','30',NULL),(1,'Character:RestRegenRaidTimeToActivate','300',NULL),(1,'Character:RestRegenPercent','3',NULL),(1,'Character:RaidExpMultiplier','0.2000000029802',NULL),(1,'World:MinGMAntiHackStatus','11',NULL),(1,'World:SoFStartZoneID','-1',NULL),(1,'Chat:KarmaUpdateIntervalMS','1200000',NULL),(1,'Character:GroupExpMultiplier','0.6499999761581',NULL),(1,'Chat:MaxMessagesBeforeKick','20',NULL),(1,'Chat:IntervalDurationMS','60000',NULL),(1,'Chat:MinimumMessagesPerInterval','4',NULL),(1,'Chat:MaximumMessagesPerInterval','12',NULL),(1,'Chat:MinStatusToBypassAntiSpam','80',NULL),(1,'Chat:EnableMailKeyIPVerification','true',NULL),(1,'Chat:EnableAntiSpam','true',NULL),(1,'Combat:WeaponSkillFalloff','0.3300000131130',NULL),(1,'Combat:ArcheryHitPenalty','0.4499999880791',NULL),(1,'Combat:MinChancetoHit','5.0000000000000',NULL),(1,'Combat:HitBonusPerLevel','1.2000000476837',NULL),(1,'Combat:HitFalloffMajor','50.0000000000000',NULL),(1,'Combat:HitFalloffModerate','7.0000000000000',NULL),(1,'Combat:HitFalloffMinor','5.0000000000000',NULL),(1,'Merchant:ChaPenaltyMod','1.5199999809265',NULL),(1,'Merchant:ChaBonusMod','3.4500000476837',NULL),(1,'Adventure:LDoNBaseTrapDifficulty','15.0000000000000',NULL),(1,'Merchant:PricePenaltyPct','4',NULL),(1,'Merchant:PriceBonusPct','4',NULL),(1,'Merchant:BuyCostMod','0.9499999880791',NULL),(1,'Merchant:SellCostMod','1.0499999523163',NULL),(1,'Merchant:UsePriceMod','true',NULL),(1,'World:GMAccountIPList','false',NULL),(1,'World:UseClientBasedExpansionSettings','true',NULL),(1,'Character:AAExpMultiplier','0.6499999761581',NULL),(1,'EventLog:RecordBuyFromMerchant','false',NULL),(1,'QueryServ:PlayerLogMerchantTransactions','false',NULL),(1,'EventLog:RecordSellToMerchant','false',NULL),(1,'QueryServ:PlayerLogDropItem','false',NULL),(1,'Chat:EnableVoiceMacros','true',NULL),(1,'Spells:TranslocateTimeLimit','0',NULL),(1,'Channels:DeleteTimer','1440',NULL),(1,'Adventure:LDoNTrapDistanceUse','625',NULL),(1,'Channels:RequiredStatusListAll','251',NULL),(1,'Channels:RequiredStatusAdmin','251',NULL),(1,'Mail:ExpireUnread','31536000',NULL),(1,'Mail:ExpireRead','31536000',NULL),(1,'Mail:ExpireTrash','0',NULL),(1,'Adventure:LDoNAdventureExpireTime','1800',NULL),(1,'Mail:EnableMailSystem','true',NULL),(1,'QueryServ:PlayerLogZone','false',NULL),(1,'Bazaar:MaxBarterSearchResults','200',NULL),(1,'Bazaar:EnableWarpToTrader','true',NULL),(1,'World:TutorialZoneID','189',NULL),(1,'Bazaar:MaxSearchResults','200',NULL),(1,'Bazaar:AuditTrail','true',NULL),(1,'World:ExemptAccountLimitStatus','200',NULL),(1,'World:TitaniumStartZoneID','-1',NULL),(1,'World:AccountSessionLimit','1',NULL),(1,'Spells:AI_PursueNoSpellMaxRecast','2000',NULL),(1,'Character:BindAnywhere','false',NULL),(1,'Character:UseDeathExpLossMult','false',NULL),(1,'Character:DeathExpLossMultiplier','3',NULL),(1,'Combat:BaseHitChance','69.0000000000000',NULL),(1,'Combat:AgiHitFactor','0.0099999997765',NULL),(1,'Spells:ResistPerLevelDiff','85',NULL),(1,'Character:SharedBankPlat','true',NULL),(1,'Spells:WizCritChance','5',NULL),(1,'Spells:WizCritRatio','0',NULL),(1,'Spells:WizCritLevel','12',NULL),(1,'Spells:BaseCritRatio','100',NULL),(1,'Spells:AI_EngagedBeneficialOtherChance','25',NULL),(1,'Spells:BaseCritChance','0',NULL),(1,'Spells:AI_EngagedDetrimentalChance','20',NULL),(1,'Combat:BaseProcChance','0.0350000001490',NULL),(1,'Combat:ProcDexDivideBy','11000.0000000000000',NULL),(1,'Combat:AvgProcsPerMinute','2.0000000000000',NULL),(1,'Combat:ProcPerMinDexContrib','0.0750000029802',NULL),(1,'Chat:ServerWideAuction','true',NULL),(1,'Combat:AdjustProcPerMinute','true',NULL),(1,'Chat:ServerWideOOC','true',NULL),(1,'Character:MaxExpLevel','70',NULL),(1,'Character:ItemATKCap','250',NULL),(1,'Zone:AutoShutdownDelay','5000',NULL),(1,'World:ClearTempMerchantlist','false',NULL),(1,'World:AddMaxClientsPerIP','-1',NULL),(1,'Spells:AI_IdleNoSpellMaxRecast','60000',NULL),(1,'Spells:AI_IdleBeneficialChance','100',NULL),(1,'World:EnableReturnHomeButton','true',NULL),(1,'World:MaxLevelForTutorial','15',NULL),(1,'World:MinOfflineTimeToReturnHome','21600',NULL),(1,'World:AddMaxClientsStatus','-1',NULL),(1,'Spells:AI_PursueDetrimentalChance','90',NULL),(1,'Spells:AI_IdleNoSpellMinRecast','6000',NULL),(1,'TaskSystem:KeepOneRecordPerCompletedTask','true',NULL),(1,'TaskSystem:EnableTaskProximity','true',NULL),(1,'World:EnableTutorialButton','true',NULL),(1,'TaskSystem:RecordCompletedOptionalActivities','true',NULL),(1,'TaskSystem:PeriodicCheckTimer','5',NULL),(1,'TaskSystem:RecordCompletedTasks','true',NULL),(1,'TaskSystem:EnableTaskSystem','true',NULL),(1,'Character:SkillUpModifier','100',NULL),(1,'NPC:EnableNPCQuestJournal','true',NULL),(1,'NPC:CorpseUnlockTimer','150000',NULL),(1,'NPC:EmptyNPCCorpseDecayTimeMS','6000',NULL),(1,'Spells:PartialHitChanceFear','0.2500000000000',NULL),(1,'World:UseBannedIPsTable','true',NULL),(1,'Zone:EnableZoneControllerGlobals','false',NULL),(1,'Pathing:Find','true',NULL),(1,'Zone:MQWarpExemptStatus','80',NULL),(1,'Character:ItemStrikethroughCap','35',NULL),(1,'Zone:MQWarpDetectionDistanceFactor','9.0000000000000',NULL),(1,'Character:ItemDoTShieldingCap','35',NULL),(1,'Character:ItemStunResistCap','35',NULL),(1,'Character:ItemSpellShieldingCap','35',NULL),(1,'Character:ItemCombatEffectsCap','100',NULL),(1,'Character:ItemShieldingCap','35',NULL),(1,'Character:ItemAccuracyCap','150',NULL),(1,'Character:ItemAvoidanceCap','100',NULL),(1,'Zone:MQZoneExemptStatus','80',NULL),(1,'Character:ItemDamageShieldCap','30',NULL),(1,'Zone:MQGhostExemptStatus','80',NULL),(1,'Zone:MQGateExemptStatus','80',NULL),(1,'Zone:EnableMQWarpDetector','true',NULL),(1,'Combat:FleeIfNotAlone','false',NULL),(1,'Zone:EnableMQZoneDetector','true',NULL),(1,'Zone:EnableMQGateDetector','true',NULL),(1,'World:MaxClientsPerIP','-1',NULL),(1,'Combat:ThrowingCritDifficulty','1100',NULL),(1,'Combat:MinRangedAttackDist','25',NULL),(1,'Aggro:PetSpellAggroMod','10',NULL),(1,'Character:DeathItemLossLevel','10',NULL),(1,'Zone:EnableMQGhostDetector','true',NULL),(1,'NPC:BuffFriends','true',NULL),(1,'Aggro:SpellAggroMod','100',NULL),(1,'Aggro:SongAggroMod','33',NULL),(1,'Combat:AssistNoTargetSelf','false',NULL),(1,'Combat:RampageHitsTarget','false',NULL),(1,'Combat:ProcTargetOnly','true',NULL),(1,'Aggro:CriticallyWoundedAggroMod','100',NULL),(1,'Aggro:CurrentTargetAggroMod','0',NULL),(1,'Aggro:MaxScalingProcAggro','400',NULL),(1,'Aggro:ClientAggroCheckInterval','6',NULL),(1,'Aggro:SittingAggroMod','35',NULL),(1,'Aggro:MeleeRangeAggroMod','20',NULL),(1,'Aggro:SmartAggroList','true',NULL),(1,'Watermap:FishingLineLength','100.0000000000000',NULL),(1,'Watermap:FishingLineStepSize','1.0000000000000',NULL),(1,'Watermap:FishingRodLength','30.0000000000000',NULL),(1,'Watermap:CheckForWaterWhenFishing','true',NULL),(1,'Spells:FocusCombatProcs','false',NULL),(1,'Watermap:CheckForWaterOnSendTo','false',NULL),(1,'Spells:PreNerfBardAEDoT','false',NULL),(1,'Watermap:CheckForWaterAtWaypoints','true',NULL),(1,'Watermap:CheckForWaterWhenMoving','true',NULL),(1,'NPC:OOCRegen','1',NULL),(1,'Watermap:CheckWaypointsInWaterWhenLoading','true',NULL),(1,'NPC:SayPauseTimeInSec','10',NULL),(1,'Combat:UseIntervalAC','true',NULL),(1,'Combat:PetAttackMagicLevel','30',NULL),(1,'Character:ItemManaRegenCap','15',NULL),(1,'Character:ItemHealthRegenCap','30',NULL),(1,'Character:HealOnLevel','false',NULL),(1,'Character:FeignKillsPet','false',NULL),(1,'Map:FixPathingZMaxDeltaWaypoint','20.0000000000000',NULL),(1,'Map:FixPathingZMaxDeltaLoading','20.0000000000000',NULL),(1,'Map:FixPathingZMaxDeltaMoving','20.0000000000000',NULL),(1,'Zone:ClientLinkdeadMS','180000',NULL),(1,'Map:FixPathingZMaxDeltaSendTo','20.0000000000000',NULL),(1,'Map:FixPathingZAtWaypoints','true',NULL),(1,'Map:FixPathingZWhenMoving','false',NULL),(1,'Map:FixPathingZOnSendTo','false',NULL),(1,'Zone:GraveyardTimeMS','1200000',NULL),(1,'Map:FixPathingZWhenLoading','true',NULL),(1,'Zone:EnableShadowrest','true',NULL),(1,'NPC:UseItemBonusesForNonPets','true',NULL),(1,'Character:ExpMultiplier','0.6499999761581',NULL),(1,'NPC:MinorNPCCorpseDecayTimeMS','600000',NULL),(1,'NPC:MajorNPCCorpseDecayTimeMS','1800000',NULL),(1,'Zone:NPCPositonUpdateTicCount','32',NULL),(1,'Zone:MinOfflineTimeToReplenishments','21600',NULL),(1,'Combat:ClientBaseCritChance','0',''),(1,'Spells:PartialHitChance','0.6999999880791',NULL),(1,'Combat:MaxChancetoHit','95.0000000000000',NULL),(1,'Spells:ResistMod','0.4000000059605',NULL),(1,'Spells:AutoResistDiff','15',NULL),(1,'Spells:ResistChance','2.0000000000000',NULL),(1,'Character:ConsumptionMultiplier','100',NULL),(1,'Combat:BerserkBaseCritChance','6',''),(1,'Combat:NPCBashKickLevel','6',NULL),(1,'Combat:WarBerBaseCritChance','3','The base crit chance for warriors and berserkers:only applies to clients'),(1,'Combat:MeleeBaseCritChance','0','The base crit chance for non warriors:NOTE: This will apply to NPCs as well'),(1,'Combat:EnableFearPathing','true',NULL),(1,'Combat:FleeHPRatio','21',NULL),(1,'World:ExemptMaxClientsStatus','-1',NULL),(1,'Combat:PetBaseCritChance','0',NULL),(1,'Combat:ArcheryCritDifficulty','3400',NULL),(1,'World:ZoneAutobootTimeoutMS','120000',NULL),(1,'World:ClientKeepaliveTimeoutMS','95000',NULL),(1,'Pets:AttackCommandRange','200.0000000000000',NULL),(1,'Skills:MaxTrainTradeskills','21',NULL),(1,'Combat:BerserkerFrenzyStart','35',NULL),(1,'Guild:MaxMembers','2048',NULL),(1,'Range:Emote','135',NULL),(1,'Character:EnduranceRegenMultiplier','100',NULL),(1,'Character:ManaRegenMultiplier','100',NULL),(1,'Character:HPRegenMultiplier','100',NULL),(1,'Character:AutosaveIntervalS','300',NULL),(1,'Character:LeaveNakedCorpses','true',NULL),(1,'Character:DeathExpLossLevel','10',NULL),(1,'Character:CorpseDecayTimeMS','43200000',NULL),(1,'GM:MinStatusToZoneAnywhere','250',NULL),(1,'Combat:HitCapPre20','40',NULL),(1,'Character:MaxLevel','70',NULL),(1,'Character:LeaveCorpses','true',NULL),(1,'Character:HasteCap','100',NULL),(1,'Character:TradeskillUpAlchemy','2',NULL),(1,'Character:MaxDraggedCorpses','2',NULL),(1,'Character:ShowExpValues','0',NULL),(1,'Character:DragCorpseDistance','400.0000000000000',NULL),(1,'Character:EnvironmentDamageMulipliter','1.0000000000000',NULL),(1,'Character:RestRegenEndurance','true',NULL),(1,'Character:UseStackablePickPocketing','true',NULL),(1,'Spells:VirusSpreadDistance','30',NULL),(1,'Spells:BaseImmunityLevel','55',NULL),(1,'Combat:ArcheryNPCMultiplier','1.0000000000000',NULL),(1,'Combat:NPCACFactor','2.2500000000000',NULL),(1,'Character:ItemCastsUseFocus','false',NULL),(1,'Character:SpamHPUpdates','false',NULL),(1,'World:ExpansionSettings','16383',NULL),(1,'World:PVPSettings','0',NULL),(1,'Spells:AI_PursueNoSpellMinRecast','500',NULL),(1,'World:FVNoDropFlag','0',NULL),(1,'World:TellQueueSize','20',NULL),(1,'Zone:GlobalLootMultiplier','1',NULL),(1,'Pathing:MinNodesLeftForLOSCheck','4',NULL),(1,'Character:MinStatusForNoDropExemptions','80',NULL),(1,'Character:OrnamentationAugmentType','20',NULL),(1,'Character:SkillCapMaxLevel','-1',NULL),(1,'Character:BaseInstrumentSoftCap','36',NULL),(1,'Character:BaseRunSpeedCap','158',NULL),(1,'Console:SessionTimeOut','600000',NULL),(1,'Pets:PetPowerLevelCap','10.0000000000000',NULL),(1,'Guild:PlayerCreationAllowed','true',NULL),(1,'Guild:PlayerCreationLimit','1',NULL),(1,'Combat:NPCAssistCapTimer','6000',NULL),(1,'Guild:PlayerCreationRequiredLevel','0',NULL),(1,'Combat:MeleePushChance','50',NULL),(1,'Guild:PlayerCreationRequiredStatus','0',NULL),(1,'Combat:NPCAssistCap','15',NULL),(1,'Guild:PlayerCreationRequiredTime','0',NULL),(1,'Combat:BerserkerFrenzyEnd','45',NULL),(1,'Spells:LiveLikeFocusEffects','true',NULL),(1,'Spells:NPCIgnoreBaseImmunity','true',NULL),(1,'NPC:StartEnrageValue','9',NULL),(1,'NPC:NPCToNPCAggroTimerMin','500',NULL),(1,'NPC:LiveLikeEnrage','false',NULL),(1,'NPC:EnableMeritBasedFaction','false',NULL),(1,'Character:ItemExtraDmgCap','150',NULL),(1,'Character:CheckCursorEmptyWhenLooting','true',NULL),(1,'Character:UnmemSpellsOnDeath','true',NULL),(1,'Character:MaintainIntoxicationAcrossZones','true',NULL),(1,'Character:UseSpellFileSongCap','true',NULL),(1,'Bots:BotAAExpansion','8','The expansion through which bots will obtain AAs'),(1,'Character:UseRaceClassExpBonuses','true',NULL),(1,'Character:UseOldRaceExpPenalties','false',NULL),(1,'Character:EnableDiscoveredItems','false',NULL),(1,'Character:KeepLevelOverMax','false',NULL),(1,'Combat:WarriorThreatBonus','0',''),(1,'Character:CorpseResTimeMS','10800000',NULL),(1,'Character:StatCap','0',NULL),(1,'Character:FoodLossPerUpdate','32',NULL),(1,'Character:SumCorpseDecayTimeMS','43200000',''),(1,'World:DeleteStaleCorpeBackups','true',NULL),(1,'Zone:UsePlayerCorpseBackups','true',NULL),(1,'Character:EnableXTargetting','true',NULL),(1,'Spells:AvgSpellProcsPerMinute','6.0000000000000',NULL),(1,'Combat:FleeMultiplier','2.0000000000000',NULL),(1,'Spells:ResistFalloff','67',NULL),(1,'Spells:AI_EngagedNoSpellMinRecast','500',NULL),(1,'Spells:CharismaEffectiveness','10',NULL),(1,'Spells:CharismaEffectivenessCap','255',NULL),(1,'Spells:AI_SpellCastFinishedFailRecast','800',NULL),(1,'Spells:CharmBreakCheckChance','25',NULL),(1,'Spells:FRProjectileItem_NPC','80684',NULL),(1,'Combat:AvgDefProcsPerMinute','2.0000000000000',NULL),(1,'Combat:DefProcPerMinAgiContrib','0.0750000029802',NULL),(1,'Adventure:LDoNCriticalFailTrapThreshold','10.0000000000000',NULL),(1,'Combat:SpecialAttackACBonus','15',NULL),(1,'Combat:ClientStunLevel','55',NULL),(1,'Combat:QuiverHasteCap','1000',NULL),(1,'Combat:FrenzyBonus','0',NULL),(1,'Combat:TauntSkillFalloff','0.3300000131130',NULL),(1,'Aggro:TunnelVisionAggroMod','0.7500000000000',NULL),(1,'Spells:MaxCastTimeReduction','50',NULL),(1,'Spells:RootBreakCheckChance','70',NULL),(1,'Spells:RootBreakFromSpells','55',NULL),(1,'Spells:DeathSaveCharismaMod','3',NULL),(1,'Spells:AdditiveBonusWornType','0',NULL),(1,'Spells:DivineInterventionHeal','8000',NULL),(1,'Combat:NPCFlurryChance','20',NULL),(1,'Combat:MonkACBonusWeight','15',NULL),(1,'AA:Stacking','true',NULL),(1,'QueryServ:PlayerLogChat','true',NULL),(1,'Spells:AdditiveBonusValues','false','Allow certain bonuses to be calculated by adding together the value from each item, instead of taking the highest value. (ie Add together all Cleave Effects)'),(1,'Character:PerCharacterQglobalMaxLevel','false',NULL),(1,'Character:EnableAvoidanceCap','false',NULL),(1,'QueryServ:PlayerLogNPCKills','false',NULL),(1,'QueryServ:PlayerLogTrades','false',NULL),(1,'QueryServ:PlayerChatLogging','false',''),(1,'QueryServ:PlayerLogMoneyTrades','false',''),(1,'QueryServ:PlayerLogPCCoordinates','false',NULL),(1,'Chat:FlowCommandstoPerl_EVENT_SAY','true',''),(1,'World:IPLimitDisconnectAll','false',NULL),(1,'World:MaxClientsSimplifiedLogic','false',NULL),(1,'World:StartZoneSameAsBindOnCreation','true',NULL),(1,'Pets:UnTargetableSwarmPet','false',NULL),(1,'Spells:SwarmPetTargetLock','false',NULL),(1,'QueryServ:MerchantLogTransactions','false',''),(1,'QueryServ:PlayerLogDeletes','false',NULL),(1,'QueryServ:PlayerLogHandins','false',NULL),(1,'QueryServ:PlayerLogMoves','false',NULL),(1,'Mercs:AllowMercs','false',NULL),(1,'Mercs:MercsUsePathing','true',NULL),(1,'Mercs:SuspendIntervalMS','10000',NULL),(1,'Mercs:UpkeepIntervalMS','180000',NULL),(1,'Mercs:SuspendIntervalS','10',NULL),(1,'Combat:WarriorACSoftcapReturn','0.4499999880791',NULL),(1,'Mercs:UpkeepIntervalS','180',NULL),(1,'Mercs:ScaleRate','100',NULL),(1,'Range:BeginCast','200',NULL),(1,'Mercs:AggroRadius','100',NULL),(1,'Range:ClientNPCScan','300',NULL),(1,'Combat:AAMitigationACFactor','3.0000000000000',NULL),(1,'Mercs:AggroRadiusPuller','25',NULL),(1,'Range:DamageMessages','50',NULL),(1,'Range:SpellMessages','75',NULL),(1,'Range:SongMessages','75',NULL),(1,'Range:MobPositionUpdates','600',NULL),(1,'Range:CriticalDamage','80',NULL),(10,'Combat:MonkDamageTableBonus','5','% bonus monks get to their damage table calcs'),(10,'Combat:DefaultRampageTargets','1','default number of people to hit with rampage'),(10,'Combat:MinRangedAttackDist','25','Minimum Distance to use Ranged Attacks'),(10,'Combat:ArcheryHitPenalty','0.25','Archery has a hit penalty to try to help balance it with the plethora of long term +hit modifiers for it'),(10,'Combat:FleeHPRatio','25','HP % when a NPC begins to flee.'),(10,'Combat:FleeMultiplier','2.0','Determines how quickly a NPC will slow down while fleeing. Decrease multiplier to slow NPC down quicker.'),(10,'Spells:CharismaEffectivenessCap','200','Deterimes how much resist modification charisma applies to charm/pacify checks. Default 10 CHA = -1 resist mod.'),(10,'Spells:BaseImmunityLevel','55','The level that targets start to be immune to stun,fear and mez spells with a max level of 0.'),(10,'Spells:MaxTotalSlotsPET','25','do not set this higher than 25 until the player profile is removed from the blob'),(10,'Spells:SacrificeMaxLevel','69','last level Sacrifice will work on'),(10,'Spells:WizCritChance','7','wizs crit chance,on top of BaseCritChance'),(10,'Pathing:CandidateNodeRangeZ','10',' When searching for path start/end nodes,only nodes within this range will be considered.'),(10,'Pathing:MinNodesLeftForLOSCheck','4','Only check for LOS when we are down to this many path nodes left to run. This next rule was put in for situations where the mob and its target may be on different sides of a hazard,e.g. a pit If the mob has LOS to its target:even though there is a hazard in its way,it may break off from the node path and run at the target,only to later detect the hazard and re-acquire a node path. Depending upon the placement of the path nodes,this can lead to the mob looping. The rule is intended to allow the mob to at least get closer to its target each time before checking LOS and trying to head straight for it.'),(10,'Zone:RadiantCrystalItemID','40903',''),(10,'Zone:LevelBasedEXPMods','false','Allows you to use the level_exp_mods table in consideration to your players EXP hits'),(10,'Zone:EbonCrystalItemID','40902',''),(10,'Zone:PEQZoneReuseTime','900','How long,in seconds,until you can reuse the #peqzone command.'),(10,'Zone:ReservedInstances','30','Will reserve this many instance ids for globals... probably not a good idea to change this while a server is running.'),(10,'Zone:MQGhostExemptStatus','-1','Required status level to exempt the MGhostDetector. Set to -1 to disable this feature.'),(10,'Zone:MQGateExemptStatus','-1','Required status level to exempt the MQGateDetector. Set to -1 to disable this feature.'),(10,'Zone:MQZoneExemptStatus','-1','Required status level to exempt the MQZoneDetector. Set to -1 to disable this feature.'),(10,'Zone:MQWarpExemptStatus','-1','Required status level to exempt the MQWarpDetector. Set to -1 to disable this feature.'),(10,'World:SoFStartZoneID','-1','Sets the Starting Zone for SoF Clients separate from Titanium Clients (-1 is disabled)'),(10,'World:MinGMAntiHackStatus','1','Minimum GM status to check against AntiHack list'),(10,'World:ExemptAccountLimitStatus','-1','Min status required to be exempt from multi-session per account limiting (-1 is disabled)'),(10,'World:AccountSessionLimit','-1','Max number of characters allowed on at once from a single account (-1 is disabled)'),(10,'World:MaxLevelForTutorial','10',''),(10,'World:ClientKeepaliveTimeoutMS','65000',''),(10,'World:ZoneAutobootTimeoutMS','60000',''),(10,'Pets:AttackCommandRange','150',''),(10,'Character:BaseRunSpeedCap','158','Base Run Speed Cap,on live its 158% which will give you a runspeed of 1.580 hard capped to 225.'),(10,'Character:BaseInstrumentSoftCap','36','Softcap for instrument mods,36 commonly referred to as 3.6 as well.'),(10,'Character:FoodLossPerUpdate','32','How much food/water you lose per stamina update'),(10,'Character:SkillCapMaxLevel','75','Sets the Max Level used for Skill Caps (from skill_caps table) -1 makes it use MaxLevel rule value. It is set to 75 because PEQ only has skillcaps up to that level,and grabbing the players skill past 75 will return 0,breaking all skills past that level. This helps servers with obsurd level caps (75+ level cap) function without any modifications.'),(10,'Character:BaseHPRegenBonusRaces','4352','a bitmask of race(s) that receive the regen bonus. Iksar (4096) & Troll (256) = 4352. see common/races.h for the bitmask values'),(10,'Character:RestRegenPercent','0','Set to >0 to enable rest state bonus HP and mana regen.'),(10,'Character:ItemATKCap','250',''),(10,'Character:ItemHealthRegenCap','30',''),(10,'Character:RedModifier','150',''),(10,'Character:YellowModifier','125',''),(10,'Character:LightBlueModifier','40',''),(10,'Character:GroupExpMultiplier','0.65',''),(10,'Character:AAExpMultiplier','0.65',''),(10,'Character:ExpMultiplier','0.65',''),(10,'Character:CorpseDecayTimeMS','10800000',''),(10,'Character:MaxExpLevel','68','Sets the Max Level attainable via Experience'),(1,'Zone:LevelBasedEXPMods','true',NULL),(1,'Mercs:ResurrectRadius','50',NULL),(1,'Range:Anims','135',NULL),(1,'Range:SpellParticles','135',NULL),(1,'Mercs:ChargeMercPurchaseCost','false',NULL),(1,'Mercs:ChargeMercUpkeepCost','false',NULL),(1,'Spells:BuffLevelRestrictions','true',NULL),(10,'Character:MaxLevel','68',''),(6,'NPC:MinorNPCCorpseDecayTimeMS','0','level<55'),(6,'Character:RestRegenTimeToActivate','300','Time in seconds for rest state regen to kick in.'),(6,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(6,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(6,'NPC:MajorNPCCorpseDecayTimeMS','0','level>=55'),(6,'Zone:GraveyardTimeMS','991200000',''),(1,'Zone:WeatherTimer','600',NULL),(10,'Combat:NPCACFactor','2.25',''),(10,'Combat:ClothACSoftcap','75',''),(10,'Combat:LeatherACSoftcap','100',''),(10,'Combat:MonkACSoftcap','120',''),(10,'Combat:ChainACSoftcap','200',''),(10,'Combat:PlateACSoftcap','300',''),(10,'Combat:AAMitigationACFactor','3.0',''),(10,'Combat:WarriorACSoftcapReturn','0.45',''),(10,'Combat:KnightACSoftcapReturn','0.33',''),(10,'Combat:LowPlateChainACSoftcapReturn','0.23',''),(10,'Combat:LowChainLeatherACSoftcapReturn','0.17',''),(10,'Combat:CasterACSoftcapReturn','0.06',''),(10,'Combat:MiscACSoftcapReturn','0.3',''),(10,'Combat:WarACSoftcapReturn','0.3448','new AC returns'),(10,'Combat:ClrRngMnkBrdACSoftcapReturn','0.3030',''),(10,'Combat:PalShdACSoftcapReturn','0.3226',''),(10,'Combat:DruNecWizEncMagACSoftcapReturn','0.2000',''),(10,'Combat:RogShmBstBerACSoftcapReturn','0.2500',''),(10,'Combat:SoftcapFactor','1.88',''),(10,'Combat:ACthac0Factor','0.55',''),(10,'Combat:ACthac20Factor','0.55',''),(10,'Combat:HitCapPre20','40','live has it capped at 40 for whatever dumb reason... this is mainly for custom servers'),(10,'Combat:HitCapPre10','20','live has it capped at 20,see above :p'),(10,'Combat:MinHastedDelay','400','how fast we can get with haste.'),(10,'Combat:TauntOverLevel','1','Allows you to taunt NPCs over warriors level.'),(10,'Combat:TauntSkillFalloff','0.33','For every taunt skill point thats not maxed you lose this % chance to taunt.'),(10,'Combat:MonkACBonusWeight','15',''),(10,'Combat:ClientStunLevel','55','This is the level where client kicks and bashes can stun the target'),(10,'Combat:QuiverWRHasteDiv','3','Weight Reduction is divided by this to get haste contribution for quivers'),(10,'Combat:ArcheryBonusChance','50',''),(10,'Combat:BerserkerFrenzyStart','35',''),(10,'Combat:BerserkerFrenzyEnd','45',''),(10,'NPC:MinorNPCCorpseDecayTimeMS','450000','level<55'),(10,'NPC:MajorNPCCorpseDecayTimeMS','1500000','level>=55'),(10,'NPC:EmptyNPCCorpseDecayTimeMS','0',''),(10,'NPC:SayPauseTimeInSec','5',''),(10,'NPC:OOCRegen','0',''),(10,'NPC:LastFightingDelayMovingMin','10000',''),(10,'NPC:LastFightingDelayMovingMax','20000',''),(10,'Aggro:MeleeRangeAggroMod','10','10%'),(10,'Aggro:TunnelVisionAggroMod','0.75','people not currently the top hate generate this much hate on a Tunnel Vision mob'),(10,'Aggro:MaxStunProcAggro','400','Set to -1 for no limit. Maxmimum amount of aggro that a stun based proc will add.'),(10,'Aggro:IntAggroThreshold','75','Int <= this will aggro regardless of level difference.'),(10,'Bots:BotManaRegen','2.0','Adjust mana regen for bots,1 is fast and higher numbers slow it down 3 is about the same as players.'),(10,'Bots:CreateBotCount','150','Number of bots that each account can create'),(10,'Bots:SpawnBotCount','71','Number of bots a character can have spawned at one time,You + 71 bots is a 12 group raid'),(10,'Chat:MinStatusToBypassAntiSpam','100',''),(10,'Chat:GlobalChatLevelLimit','1','level limit you need to of reached to talk in ooc/auction/chat if your karma is too low.'),(10,'Bazaar:MaxSearchResults','50',''),(10,'Adventure:NumberKillsForBossSpawn','45',''),(10,'Adventure:LDoNTrapDistanceUse','625',''),(10,'Adventure:LDoNBaseTrapDifficulty','15.0',''),(10,'Adventure:LDoNCriticalFailTrapThreshold','10.0',''),(10,'Adventure:LDoNAdventureExpireTime','1800','30 minutes to expire'),(1,'Spells:CharismaCharmDuration','false',NULL),(1,'Spells:CharismaResistCap','255','Maximium amount of CHA that will effect charm resist rate.'),(1,'Inventory:EnforceAugmentRestriction','false',NULL),(1,'Inventory:EnforceAugmentUsability','false',NULL),(1,'Inventory:EnforceAugmentWear','false',NULL),(1,'Spells:FearBreakCheckChance','70',NULL),(1,'Spells:FRProjectileItem_SOF','80684',NULL),(10,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(1,'Spells:SuccorFailChance','1',NULL),(1,'Spells:FRProjectileItem_Titanium','1113',NULL),(2,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(6,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(1,'Combat:AvgSpecialProcsPerMinute','2.0000000000000',NULL),(4,'NPC:MinorNPCCorpseDecayTimeMS','1800000','level<55'),(4,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(4,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(4,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(1,'Client:UseLiveFactionMessage','true',NULL),(1,'Client:UseLiveBlockedMessage','false',NULL),(1,'Character:ActiveInvSnapshots','false',NULL),(1,'Character:RestrictSpellScribing','false',NULL),(1,'Character:InvSnapshotMinIntervalM','180',NULL),(1,'Combat:KnightACSoftcapReturn','0.3300000131130',NULL),(1,'Character:InvSnapshotMinRetryM','30',NULL),(1,'Character:AvoidanceCap','750',NULL),(1,'Character:InvSnapshotHistoryD','30',NULL),(1,'Spells:SHDProcIDOffByOne','false',NULL),(5,'Character:RestRegenTimeToActivate','300','Time in seconds for rest state regen to kick in.'),(5,'NPC:EmptyNPCCorpseDecayTimeMS','0','notation'),(5,'NPC:LastFightingDelayMovingMax','20000','Maximum time (in ms) before mob goes home after all aggro loss'),(5,'NPC:MinorNPCCorpseDecayTimeMS','1800000','level<55'),(5,'Spells:SuccorFailChance','2','Determines chance for a succor spell not to teleport an invidual player.'),(5,'Zone:GraveyardTimeMS','991200000',''),(1,'Spells:Jun182014HundredHandsRevamp','true',NULL),(1,'Combat:LevelToStopDamageCaps','0',NULL),(1,'Range:Say','135',NULL),(1,'Character:GrantHoTTOnCreate','false',NULL),(1,'Character:UseOldConSystem','false',NULL),(1,'World:EnableIPExemptions','false',NULL),(1,'Character:EnableAggroMeter','true',NULL),(1,'Aggro:IntAggroThreshold','20',NULL),(1,'Character:TradeskillUpFletching','2',NULL),(1,'Character:TradeskillUpJewelcrafting','2',NULL),(1,'Character:TradeskillUpMakePoison','2',NULL),(1,'Character:TradeskillUpPottery','4',NULL),(1,'Character:TradeskillUpResearch','1',NULL),(1,'Character:TradeskillUpTinkering','2',NULL),(1,'Character:IksarCommonTongue','95',NULL),(1,'Character:OgreCommonTongue','95',NULL),(1,'Character:TrollCommonTongue','95',NULL),(1,'Combat:LowPlateChainACSoftcapReturn','0.2300000041723',NULL),(1,'Combat:LowChainLeatherACSoftcapReturn','0.1700000017881',NULL),(1,'Combat:CasterACSoftcapReturn','0.0599999986589',NULL),(1,'Combat:MiscACSoftcapReturn','0.3000000119209',NULL),(1,'Combat:WarACSoftcapReturn','0.3447999954224',NULL),(1,'Combat:ClrRngMnkBrdACSoftcapReturn','0.3030000030994',NULL),(1,'Combat:PalShdACSoftcapReturn','0.3226000070572',NULL),(1,'Combat:DruNecWizEncMagACSoftcapReturn','0.2000000029802',NULL),(1,'Combat:RogShmBstBerACSoftcapReturn','0.2500000000000',NULL),(1,'Combat:SoftcapFactor','1.8799999952316',NULL),(1,'Combat:ACthac0Factor','0.5500000119209',NULL),(1,'Combat:ACthac20Factor','0.5500000119209',NULL),(1,'Character:AllowMQTarget','false',NULL),(1,'Character:UseOldBindWound','false',NULL),(1,'Mercs:AllowMercSuspendInCombat','true',NULL),(1,'Spells:NPC_UseFocusFromItems','false',NULL),(1,'Spells:UseAdditiveFocusFromWornSlot','false',NULL),(1,'Spells:AlwaysSendTargetsBuffs','false',NULL),(1,'Spells:FlatItemExtraSpellAmt','false',NULL),(1,'Spells:IgnoreSpellDmgLvlRestriction','false',NULL),(1,'Spells:AllowItemTGB','false',NULL),(1,'Spells:NPCInnateProcOverride','true',NULL),(1,'Combat:NPCCanCrit','false',NULL),(1,'Combat:TauntOverLevel','true',NULL),(1,'Combat:EXPFromDmgShield','false',NULL),(1,'Combat:UseArcheryBonusRoll','false',NULL),(1,'Combat:OneProcPerWeapon','true',NULL),(1,'Combat:ProjectileDmgOnImpact','true',NULL),(1,'Combat:MeleePush','true',NULL),(1,'Combat:UseLiveCombatRounds','true',NULL),(1,'Combat:UseRevampHandToHand','false',NULL),(1,'Combat:ClassicMasterWu','false',NULL),(1,'Aggro:UseLevelAggro','true',NULL),(1,'Chat:SuppressCommandErrors','false',NULL),(1,'Merchant:EnableAltCurrencySell','true',NULL),(1,'QueryServ:PlayerLogDeaths','false',NULL),(1,'QueryServ:PlayerLogConnectDisconnect','false',NULL),(1,'QueryServ:PlayerLogLevels','false',NULL),(1,'QueryServ:PlayerLogAARate','false',NULL),(1,'QueryServ:PlayerLogQGlobalUpdate','false',NULL),(1,'QueryServ:PlayerLogTaskUpdates','false',NULL),(1,'QueryServ:PlayerLogKeyringAddition','false',NULL),(1,'QueryServ:PlayerLogAAPurchases','false',NULL),(1,'QueryServ:PlayerLogTradeSkillEvents','false',NULL),(1,'QueryServ:PlayerLogIssuedCommandes','false',NULL),(1,'QueryServ:PlayerLogMoneyTransactions','false',NULL),(1,'QueryServ:PlayerLogAlternateCurrencyTransactions','false',NULL),(1,'Inventory:DeleteTransformationMold','true',NULL),(1,'Inventory:AllowAnyWeaponTransformation','false',NULL),(1,'Inventory:TransformSummonedBags','false',NULL),(1,'Spells:OldRainTargets','false',NULL),(1,'Map:FixZWhenMoving','true',NULL),(1,'Pathing:ZDiffThresholdNew','80.0000000000000',NULL),(1,'Map:MobZVisualDebug','false',NULL),(1,'Spells:ReflectMessagesClose','true',NULL),(1,'Range:MobCloseScanDistance','200',NULL),(1,'Character:OPClientUpdateVisualDebug','false',NULL),(1,'Range:ClientPositionUpdates','300',NULL),(1,'Range:ClientForceSpawnUpdateRange','1000',NULL),(1,'Character:RestRegenHP','180',NULL),(1,'Character:RestRegenMana','180',NULL),(1,'Character:RestRegenEnd','180',NULL),(1,'Character:RestRegenEnabled','true',NULL),(1,'Character:EnableHungerPenalties','false',NULL),(1,'Skills:SelfLanguageLearning','true',NULL),(1,'Character:OldMinMana','false',NULL),(1,'Character:UseOldRaceRezEffects','false',NULL),(1,'Pets:CanTakeNoDrop','false',NULL),(1,'Combat:ClassicNPCBackstab','false',NULL),(1,'AA:NormalizedAANumberOfWhiteConPerAA','25',NULL),(1,'AA:ModernAAScalingAAMinimum','0',NULL),(1,'AA:ModernAAScalingAALimit','4000',NULL),(1,'AA:ModernAAScalingStartPercent','1000.0000000000000',NULL),(1,'AA:NormalizedAAEnabled','false',NULL),(1,'AA:ModernAAScalingEnabled','false',NULL),(1,'Character:PetsUseReagents','true',NULL),(1,'Bugs:ReportingSystemActive','true',NULL),(1,'Bugs:UseOldReportingMethod','true',NULL),(1,'Bugs:DumpTargetEntity','false',NULL),(1,'World:PVPMinLevel','0',NULL),(1,'Chat:ExpireClientVersionRequests','3',NULL),(1,'Chat:ExpireClientVersionReplies','30',NULL),(1,'Chat:UCSBroadcastServerReadyDelay','60',NULL),(1,'Spells:NPCSpellPush','true',NULL),(1,'Aggro:PetAttackRange','40000.0000000000000',NULL),(1,'NPC:UseBaneDamage','false',NULL),(1,'Character:AllowCrossClassTrainers','false',NULL),(1,'Aggro:NPCAggroMaxDistanceEnabled','true',NULL),(1,'Character:DismountWater','true',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variables` (
  `varname` varchar(25) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `information` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`varname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `variables` VALUES ('AAXPMod','0.75','AA Experience multipler. Increase to increase exp rate','2010-09-06 15:03:51'),('ACfail','15','the percentage of time AC fails to protect. 0 would mean there was always some level of protection, 100 would mean AC has no affect. When AC fails, it will be possible to get a max dmg hit.','2010-09-06 15:03:51'),('ACrandom','20','','2010-09-06 15:03:51'),('ACreduction','3','','2010-09-06 15:03:51'),('ailevel','6','','2010-09-06 15:03:51'),('curInstFlagNum','2002','Determines what instance flag will be handed out next','2010-09-06 15:03:51'),('DBVersion','070_pop','DB version info','2010-09-06 15:03:51'),('decaytime 1 54','480','Corpse decay time for Level\'s 1 to 54','2010-09-06 15:03:51'),('decaytime 55 100','1800','Corpse decay time for Level\'s 55 to 100','2010-09-06 15:03:51'),('dfltInstZflag','1000','Used to determine if a zone is instanced, must be 1000 or greater','2010-09-06 15:03:51'),('disablecommandline','0','Allow command lines to be run from world.exe | 0 - off | 1 - on |','2010-09-06 15:03:51'),('Expansions','16383','Accessible expansions for each player','2010-09-06 15:03:51'),('EXPMod','0.75','Experience multipler. Increase to increase exp rate','2010-09-06 15:03:51'),('GroupEXPBonus','0.60','Experience multipler. Increase to increase group exp rate','2010-09-06 15:03:51'),('GuildWars','0','Enable Guild Wars Type Server | 0 - off | 1 - on |','2010-09-06 15:03:51'),('holdzones','0','Restart Crashed Zone Servers | 0 - off | 1 - on |','2010-09-06 15:03:51'),('leavecorpses','0','Players leave corpses | 0 - off | 1 - on |','2010-09-06 15:03:51'),('loglevel','7','Commands,Merchants,Trades,Loot','2017-05-11 01:06:35'),('Max_AAXP','21626880','Max AA Experience','2010-09-06 15:03:51'),('MerchantsKeepItems','1','Merchants keep items sold to them | 0 - off | 1 - on |','2010-09-06 15:03:51'),('MOTD','Welcome to PEQ: http://www.peqtgc.com. Use our RoF2 Client! In the [General] Forum read Setup Guide and Server FAQ. use E3/MQ section on new forums for questions','','2017-09-05 02:03:24'),('fixed_heading','1','','2018-02-16 18:28:40'),('hotfix_name','','','2016-11-18 10:07:03');
