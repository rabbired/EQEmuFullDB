I suck at writing up directions, but to quickly summarize.

In the below examples, replace blahblah with the exact name of the file, which will be the date it was created.

New install at a mysql prompt:

create database whatever_db_name_you_want;
use whatever_db_name_you_made;
source peqbeta_blahblah.sql;
source player_tables_blahblah.sql;
(OPTIONAL) source load_login.sql;
(OPTIONAL) source load_bots.sql;

copy eqtime.cfg over to the directory where your server binaries live.

If you plan on using the public EQEmu login server, then sourcing load_login.sql is not necessary. 
If you wish to use a local login, you can login using Admin and the password "password". You can also look in load_login.sql to see how to add your own users manually.

-----------------------------------------------------

PLEASE NOTE: Upgrading will get you current for the data contained within the system tables (peqbeta) and the data tables if you source it. However, player tables will need to be updated manually by you using any new .sql on the EQEmu git. (See end of this file for link)
Upgrade install at a mysql prompt:

use whatever_db_name_you_made;
source drop_system.sql;
source peqbeta_blahblah.sql;
(OPTIONAL) source data_tables_blahblah.sql;

copy eqtime.cfg over to the directory where your server binaries live.

Sourcing data_tables.sql will remove any changes you made to rules, variables, launcher, or commands. If you don't ever change those tables, I recommend sourcing it.
Upgrading does not remove any player (character) data but will wipe all content data. So, if you added spawns, items, etc back them up before upgrading!

-----------------------------------------------------

What do these files all do?

eqtime.cfg - This is the EQEmu time file, and is required to make sure your server is in sync with PEQ. If it isn't, spawns that depend on time of day will not work properly.
data_tables_.sql - Contains the newest commands, launcher, rule_sets, rule_values, and variables tables. This is not required for fresh installs, but is recommended for upgrades.
drop_bots.sql - Use this if you want to remove bots from the DB.
drop_system.sql - Drops the content tables of your DB (items, spells, spawns, faction, zone data, doors, objects, etc)
load_bots.sql - Optional tables for bots support.
load_login.sql - Loads the tables required to run a local login server. This is not required if you are using the public EQEmu server.
peqbeta_.sql - This is the actual PEQ database. It contains all the content we are developing.
player_tables_.sql - For fresh installs ONLY. This contains the player tables (character_, accounts, inventory, etc) and also the data tables (commands, launcher, rule_sets, rule_values, and variables.)
source_views.sql - Not used by us atm, it's for merc support.   

-----------------------------------------------------

Project home is:

http://www.peqtgc.com/phpBB3/

Git for EQEmu code:

https://github.com/EQEmu/Server

Daily DB, Quest, and Editor dump:

https://drive.google.com/folderview?id=0B5FZHGN6aazfeThIMENvWTA2VDA&usp=sharing#list